/*
 * Copyright (C) 2017-2019 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 *
 */

namespace NEO {
bool isDeferredDeleterEnabled();
} // namespace NEO
