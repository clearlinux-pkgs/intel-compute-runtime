/*
 * Copyright (C) 2019 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 *
 */

#include "runtime/os_interface/os_library.h"

#include "offline_compiler.h"

namespace NEO {
void OfflineCompiler::resolveExtraSettings() {}
} // namespace NEO
