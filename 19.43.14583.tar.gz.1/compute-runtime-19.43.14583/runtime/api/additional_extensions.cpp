/*
 * Copyright (C) 2019 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 *
 */

#include "runtime/api/additional_extensions.h"

namespace NEO {
void *CL_API_CALL getAdditionalExtensionFunctionAddress(const char *funcName) {
    return nullptr;
}

} // namespace NEO
