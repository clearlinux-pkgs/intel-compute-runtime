/*
 * Copyright (C) 2017-2018 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 *
 */

#include "runtime/aub_mem_dump/aub_mem_dump.h"

namespace AubMemDump {
void LrcaHelper::setContextSaveRestoreFlags(uint32_t &ctxSrCtlValue) const {
}
} // namespace AubMemDump
