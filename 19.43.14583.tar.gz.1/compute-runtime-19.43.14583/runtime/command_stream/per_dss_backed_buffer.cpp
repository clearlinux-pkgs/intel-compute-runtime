/*
 * Copyright (C) 2019 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 *
 */

#include "runtime/command_stream/command_stream_receiver.h"

namespace NEO {

bool CommandStreamReceiver::createPerDssBackedBuffer(Device &device) {
    return true;
}
} // namespace NEO
