/*
 * Copyright (C) 2018-2019 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 *
 */

#include "runtime/os_interface/linux/os_interface.h"

namespace NEO {

bool OSInterface::osEnableLocalMemory = true;

} // namespace NEO