/*
 * Copyright (C) 2019 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 *
 */

#include "runtime/execution_environment/execution_environment.h"

namespace NEO {
bool ExecutionEnvironment::initializeRootCommandStreamReceiver(RootDevice &device) {
    return false;
}

} // namespace NEO
